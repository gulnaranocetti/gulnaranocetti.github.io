#include "../include/conjuntoPiezas.h"

struct rep_conjuntopiezas {
    int cantMax;
    int cardinal;
    bool *piezas;
};

TConjuntoPiezas crearTConjuntoPiezas(int cantMax){ 
    TConjuntoPiezas c = new rep_conjuntopiezas;
    c -> cantMax = cantMax;
    c -> cardinal = 0;
    c -> piezas = new bool[cantMax];
    for(int i = 0; i < cantMax; i++)
        c -> piezas[i] = false;
    return c; 
}

bool esVacioTConjuntoPiezas(TConjuntoPiezas c){ 
    return c -> cardinal == 0; 
}

void insertarTConjuntoPiezas(TConjuntoPiezas &c, int id){
    if(id >= 0 && id < c -> cantMax && !c -> piezas[id]){
        c -> piezas[id] = true;
        c -> cardinal++;
    }
}

void borrarDeTConjuntoPiezas(TConjuntoPiezas &c, int id){
    if(id >= 0 && id < c -> cantMax && c -> piezas[id]){
        c -> piezas[id] = false;
        c -> cardinal--;
    }
}

bool perteneceTConjuntoPiezas(TConjuntoPiezas c, int id){ 
    return id >= 0 && id < c -> cantMax && c -> piezas[id]; 
}

int cardinalTConjuntoPiezas(TConjuntoPiezas c){ 
    return c -> cardinal; 
}

int cantMaxTConjuntoPiezas(TConjuntoPiezas c){ 
    return c -> cantMax; 
}

void imprimirTConjuntoPiezas(TConjuntoPiezas c){
    for(int i = 0; i < c -> cantMax; i++){
        if(c -> piezas[i])
            printf("%d ", i);
    } printf("\n");
}

void liberarTConjuntoPiezas(TConjuntoPiezas &c){
    delete[] c -> piezas;
    delete c;
    c = NULL;
}

TConjuntoPiezas unionTConjuntoPiezas(TConjuntoPiezas c1, TConjuntoPiezas c2){ 
    int n = c1 -> cantMax;
    TConjuntoPiezas conjuntoUnion = crearTConjuntoPiezas(n);
    for(int i = 0; i < n; i++){
        if(c1->piezas[i] || c2->piezas[i])
            insertarTConjuntoPiezas(conjuntoUnion, i);
    }
    return conjuntoUnion; 
}

TConjuntoPiezas interseccionTConjuntoPiezas(TConjuntoPiezas c1, TConjuntoPiezas c2){ 
    int n = c1 -> cantMax;
    TConjuntoPiezas conjuntoInter = crearTConjuntoPiezas(n);
    for(int i = 0; i < n; i++){
        if(c1->piezas[i] && c2->piezas[i])
            insertarTConjuntoPiezas(conjuntoInter, i);
    }
    return conjuntoInter; 
}

TConjuntoPiezas diferenciaTConjuntoPiezas(TConjuntoPiezas c1, TConjuntoPiezas c2){ 
    int n = c1 -> cantMax;
    TConjuntoPiezas conjuntoDif = crearTConjuntoPiezas(n);
    for(int i = 0; i < n; i++){
        if(c1->piezas[i] && !c2->piezas[i])
            insertarTConjuntoPiezas(conjuntoDif, i);
    }
    return conjuntoDif;  
}
