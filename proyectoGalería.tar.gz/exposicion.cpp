#include "../include/exposicion.h"

struct rep_exposicion {
    int id;
    TFecha fechaIni;
    TFecha fechaFin;
    TConjuntoPiezas piezas;
};

TExposicion crearTExposicion(int idExp, TFecha ini, TFecha fin, int cantMax){
    TExposicion expo = new rep_exposicion;
    expo -> id = idExp;
    expo -> fechaIni = ini;
    expo -> fechaFin = fin;
    expo -> piezas = crearTConjuntoPiezas(cantMax); 
    return expo; 
}

void agregarATExposicion(TExposicion &exp, TPieza p){
    insertarTConjuntoPiezas(exp -> piezas, idTPieza(p));
}

bool perteneceATExposicion(TExposicion exp, TPieza p){ 
    return perteneceTConjuntoPiezas(exp -> piezas, idTPieza(p)); 
}

int idTExposicion(TExposicion exp){ 
    return exp -> id;
}

void imprimirTExposicion(TExposicion exp){
    printf("Exposicion #%d del ", exp -> id);
    imprimirTFecha(exp -> fechaIni);
    printf(" al ");
    imprimirTFecha(exp -> fechaFin);
    printf("\nPiezas: ");
    imprimirTConjuntoPiezas(exp -> piezas);
}

TFecha fechaInicioTExposicion(TExposicion exp){ 
    return exp -> fechaIni;
}

TFecha fechaFinTExposicion(TExposicion exp){ 
    return exp -> fechaFin;
}

bool sonExposicionesCompatibles(TExposicion exp1, TExposicion exp2){
    if(compararTFechas(exp1 -> fechaIni, exp2 -> fechaFin) == 1 || 
        compararTFechas(exp2 -> fechaIni, exp1 -> fechaFin) == 1) 
        return true;
    TConjuntoPiezas inter = interseccionTConjuntoPiezas(exp1 -> piezas, exp2 -> piezas);
    bool compatibles = esVacioTConjuntoPiezas(inter);
    liberarTConjuntoPiezas(inter);
    return compatibles;
}

void liberarTExposicion(TExposicion &exp){
    liberarTFecha(exp -> fechaIni);
    liberarTFecha(exp -> fechaFin);
    liberarTConjuntoPiezas(exp -> piezas);
    delete exp;
    exp = NULL;
}

// Agregados tarea 4

TConjuntoPiezas obtenerPiezasTExposicion(TExposicion expo){
    return expo->piezas;
}
