#include "../include/galeria.h"

struct rep_galeria{
    TColeccionPiezas piezasColeccion;
    TConjuntoPiezas piezasConjunto;
    TVisitaDia visitaActual;
    TFecha fechaActual;
    TListaExposiciones activas;
    TListaExposiciones finalizadas;
    TListaExposiciones futuras;
    THashVisitaDia visitasPasadas;
};

TGaleria crearTGaleria(TFecha fecha){
    TGaleria nueva = new rep_galeria;
    nueva->piezasColeccion = crearColeccionPiezasVacia();
    TFecha fechaActual = copiarTFecha(fecha);
    nueva->fechaActual = fechaActual;
    nueva->piezasConjunto = crearTConjuntoPiezas(MAX_PIEZAS);
    nueva->visitaActual = crearTVisitaDia(fecha, MAX_GRUPOS_VISITA_DIA);
    nueva->activas = crearTListaExposicionesVacia();
    nueva->finalizadas = crearTListaExposicionesVacia();
    nueva->futuras = crearTListaExposicionesVacia();
    nueva->visitasPasadas = crearTHashVisitaDia(CANT_ESTIMADA_VISITA_DIA_PASADAS);
    return nueva;
}

void agregarPiezaTGaleria(TGaleria galeria, TPieza pieza){
    insertarPiezaColeccionPiezas(galeria -> piezasColeccion, pieza);
    insertarTConjuntoPiezas(galeria->piezasConjunto, idTPieza(pieza));
}

void agregarExposicionTGaleria(TGaleria galeria, TExposicion expo){
    if(compararTFechas(fechaFinTExposicion(expo),galeria -> fechaActual)== -1)
        agregarExposicionTListaExposiciones(galeria -> finalizadas, expo);
    else if(compararTFechas(fechaInicioTExposicion(expo), galeria -> fechaActual) == -1)
        agregarExposicionTListaExposiciones(galeria -> activas, expo);
    else
        agregarExposicionTListaExposiciones(galeria -> futuras, expo);
}

void agregarPiezaAExposicionTGaleria(TGaleria galeria, int idPieza, int idExpo){

    TPieza p = obtenerPiezaColeccionPiezas(galeria -> piezasColeccion, idPieza);
    
    if(perteneceExposicionTListaExposiciones(galeria -> finalizadas, idExpo)){
        TExposicion expo = obtenerExposicionTListaExposiciones(galeria -> finalizadas, idExpo);
        agregarATExposicion(expo, p);
    }
    else if(perteneceExposicionTListaExposiciones(galeria -> activas, idExpo)){
        TExposicion expo = obtenerExposicionTListaExposiciones(galeria -> activas, idExpo);
        agregarATExposicion(expo, p);
    } else{
        TExposicion expo = obtenerExposicionTListaExposiciones(galeria -> futuras, idExpo);
        agregarATExposicion(expo, p);
    }
}

void imprimirExposicionesFinalizadasTGaleria(TGaleria galeria){
    imprimirTListaExposiciones(galeria -> finalizadas);
}

void imprimirExposicionesActivasTGaleria(TGaleria galeria){
    imprimirTListaExposiciones(galeria -> activas);
}

void imprimirExposicionesFuturasTGaleria(TGaleria galeria){
    imprimirTListaExposiciones(galeria -> futuras);
}

bool esCompatibleExposicionTGaleria(TGaleria galeria, TExposicion expo){
    return esCompatibleTListaExposiciones(galeria->finalizadas, expo) && esCompatibleTListaExposiciones(galeria -> activas, expo)
        && esCompatibleTListaExposiciones(galeria -> futuras, expo); 
}

void avanzarAFechaTGaleria(TGaleria galeria, TFecha fecha){
    liberarTFecha(galeria -> fechaActual);
    galeria -> fechaActual = fecha;

    agregarVisitaDiaTHashVisitaDia(galeria->visitasPasadas, galeria->visitaActual);
    galeria->visitaActual = crearTVisitaDia(copiarTFecha(fecha), MAX_GRUPOS_VISITA_DIA);
    
    TListaExposiciones f1 = obtenerExposicionesFinalizadas(galeria -> activas, fecha);
    TListaExposiciones f2 = obtenerExposicionesFinalizadas(galeria -> futuras, fecha);
    TListaExposiciones nuevasFinalizadas = unirListaExposiciones(f1, f2);
    liberarTListaExposiciones(f1, false);
    liberarTListaExposiciones(f2,false);

    TListaExposiciones finalizadas = unirListaExposiciones(nuevasFinalizadas, galeria -> finalizadas);
    liberarTListaExposiciones(galeria -> finalizadas, false);
    galeria -> finalizadas = finalizadas;
    
    TListaExposiciones nuevasActivas = obtenerExposicionesActivas(galeria -> futuras, fecha);
    TListaExposiciones activas = unirListaExposiciones(nuevasActivas, galeria -> activas);
    liberarTListaExposiciones(galeria -> activas, false);
    galeria -> activas = activas;


    liberarTListaExposiciones(nuevasFinalizadas, false);
    liberarTListaExposiciones(nuevasActivas, false);
}

void liberarTGaleria(TGaleria &galeria){
    liberarTConjuntoPiezas(galeria->piezasConjunto);
    liberarColeccionPiezas(galeria->piezasColeccion);
    liberarTListaExposiciones(galeria->activas, true);
    liberarTListaExposiciones(galeria->finalizadas, true);
    liberarTListaExposiciones(galeria->futuras, true);
    liberarTHashVisitaDia(galeria->visitasPasadas);
    liberarTVisitaDia(galeria->visitaActual);
    liberarTFecha(galeria->fechaActual);
    delete galeria;
    galeria = NULL;
}

// Funciones tarea 4

TConjuntoPiezas piezasEnExposicionTGaleria(TGaleria galeria){
    TConjuntoPiezas piezasActivas = crearTConjuntoPiezas(MAX_PIEZAS);
    for(int i = 1; i <= cantidadExposicionesTListaExposiciones(galeria->activas); i++){
        TExposicion expo = obtenerNesimaExposicionTListaExposiciones(galeria->activas, i);
        TConjuntoPiezas nuevas = obtenerPiezasTExposicion(expo);
        TConjuntoPiezas aux = unionTConjuntoPiezas(piezasActivas, nuevas);
        liberarTConjuntoPiezas(piezasActivas);
        piezasActivas = aux;
    }
    return piezasActivas;
}

float indiceFelicidadVisitanteTGaleria(TGaleria galeria, TVisitante visitante){
    TConjuntoPiezas favoritasVistante = obtenerPiezasFavoritasTVisitante(visitante);
    float cpf = cardinalTConjuntoPiezas(favoritasVistante);
    if(cpf == 0)
        return 1.0;
    TConjuntoPiezas enExpo = piezasEnExposicionTGaleria(galeria);
    TConjuntoPiezas favoritasEnExpo = interseccionTConjuntoPiezas(enExpo, favoritasVistante);
    float cpfe = cardinalTConjuntoPiezas(favoritasEnExpo);

    liberarTConjuntoPiezas(favoritasEnExpo);
    liberarTConjuntoPiezas(enExpo);

    return cpfe/cpf;
}

void llegaGrupoTGaleria(TGaleria galeria, TGrupoABB grupoABB){
    encolarGrupoTVisitaDia(galeria->visitaActual, grupoABB);
}

TConjuntoPiezas piezasEnReservaTGaleria(TGaleria galeria){  
    TConjuntoPiezas piezasEnExpo = piezasEnExposicionTGaleria(galeria);
    TConjuntoPiezas piezasEnReserva = diferenciaTConjuntoPiezas(galeria->piezasConjunto, piezasEnExpo);
    liberarTConjuntoPiezas(piezasEnExpo);
    return piezasEnReserva;
}

TVisitaDia obtenerVisitaDiaTGaleria(TGaleria galeria, TFecha fecha){
    if(compararTFechas(galeria->fechaActual, fecha) == 0)
        return galeria->visitaActual;
    return obtenerVisitaDiaTHashVisitaDia(galeria->visitasPasadas, fecha);
}
