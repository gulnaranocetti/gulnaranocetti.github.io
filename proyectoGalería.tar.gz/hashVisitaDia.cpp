
#include "../include/hashVisitaDia.h"

typedef struct rep_nodo* nodo;

struct rep_nodo{
    nodo sig;
    TVisitaDia visitaDia;
};


struct rep_hashvisitadia {
    int capacidad;
    nodo* tabla;
};

// interna funcion hash
int funcionHash(TFecha fecha, int cantEstimadas){
    return (31 * (int) mesTFecha(fecha) + (int) diaTFecha(fecha)) % cantEstimadas;
}

THashVisitaDia crearTHashVisitaDia(int cantEstimadas){
    THashVisitaDia hash = new rep_hashvisitadia;
    hash->capacidad = cantEstimadas;
    hash->tabla = new nodo[cantEstimadas];
    for(int i = 0; i < cantEstimadas; i++)
        hash->tabla[i] = NULL;
    return hash;
}

void agregarVisitaDiaTHashVisitaDia(THashVisitaDia hash, TVisitaDia visitaDia){
    int pos = funcionHash(fechaTVisitaDia(visitaDia), hash->capacidad);
    nodo nueva = new rep_nodo;
    nueva->visitaDia = visitaDia;
    nueva->sig = hash->tabla[pos];
    hash->tabla[pos] = nueva;
}

void imprimirTHashVisitaDia(THashVisitaDia hash){
    for(int i = 0; i < hash->capacidad; i++){
        if(hash->tabla[i] == NULL)
            printf("No hay elementos guardados la posicion %d de la tabla.\n", i);
        else {
            nodo actual = hash->tabla[i];
            printf("Elementos en la posicion %d de la tabla:\n", i);
            while(actual != NULL){
                imprimirTVisitaDia(actual->visitaDia);
                actual = actual->sig;
            }
        }
    }
}

TVisitaDia obtenerVisitaDiaTHashVisitaDia(THashVisitaDia hash, TFecha fecha){
    nodo actual = hash->tabla[funcionHash(fecha, hash->capacidad)];
    while(actual != NULL){
        if(compararTFechas(fechaTVisitaDia(actual->visitaDia), fecha) == 0)
            return actual->visitaDia;
        actual = actual -> sig;
    }
    return NULL;
}

bool perteneceVisitaDiaTHashVisitaDia(THashVisitaDia hash, TFecha fecha){
    nodo actual = hash->tabla[funcionHash(fecha, hash->capacidad)];
    while(actual != NULL){
        if(compararTFechas(fechaTVisitaDia(actual->visitaDia), fecha) == 0)
            return true;
        actual = actual -> sig;
    }
    return false;
}

void liberarTHashVisitaDia(THashVisitaDia &hash){
    for(int i = 0; i < hash->capacidad; i++){
        nodo actual = hash->tabla[i];
        while(actual != NULL){
            nodo aBorrar = actual;
            liberarTVisitaDia(aBorrar->visitaDia);
            actual = actual->sig;
            delete aBorrar;
        }
    }
    delete[] hash->tabla;
    delete hash;
    hash = NULL;
}
