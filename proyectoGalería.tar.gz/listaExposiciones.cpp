#include "../include/listaExposiciones.h"

struct nodo_listaexposiciones {
    TExposicion expo;
    nodo_listaexposiciones *sig;
};

typedef struct nodo_listaexposiciones * nodo;

struct rep_listaexposiciones {
    nodo inicio;
    int cantElem;
};

TListaExposiciones crearTListaExposicionesVacia(){ 
    TListaExposiciones listaExpo = new rep_listaexposiciones;
    listaExpo -> inicio = NULL; 
    listaExpo->cantElem = 0;
    return listaExpo; 
}

void agregarExposicionTListaExposiciones(TListaExposiciones &listaExposiciones, TExposicion expo){
    nodo nuevoExp = new nodo_listaexposiciones;
    nuevoExp -> expo = expo;
    nuevoExp -> sig = NULL;

    // si la lista es vacía o la primer fecha de inicio es mayor a la fecha inicio de expo, agregar al compienzo
    if(listaExposiciones -> inicio == NULL || 
        compararTFechas(fechaInicioTExposicion(listaExposiciones->inicio->expo), fechaInicioTExposicion(expo)) > -1){
        nuevoExp -> sig = listaExposiciones -> inicio;
        listaExposiciones -> inicio = nuevoExp;
    } 
    
    else {
        nodo actual = listaExposiciones -> inicio;
        while(actual -> sig != NULL && compararTFechas(fechaInicioTExposicion(actual -> sig ->expo), fechaInicioTExposicion(expo)) == -1)
            actual = actual -> sig;
        nuevoExp -> sig = actual -> sig;
        actual -> sig = nuevoExp;
    } 
    listaExposiciones->cantElem++;
}

bool perteneceExposicionTListaExposiciones(TListaExposiciones listaExposiciones, int idExpo){ 
    nodo actual = listaExposiciones -> inicio;
    while(actual != NULL && idExpo != idTExposicion(actual -> expo)){
        actual = actual -> sig;
    }
    return actual != NULL;
}

TExposicion obtenerExposicionTListaExposiciones(TListaExposiciones listaExposiciones, int idExpo){ 
    nodo actual = listaExposiciones -> inicio;
    while(actual != NULL && idExpo != idTExposicion(actual -> expo)){
        actual = actual -> sig;
    }
    return actual -> expo; 
}

bool esVaciaTListaExposiciones(TListaExposiciones listaExposiciones){ 
    return listaExposiciones -> inicio == NULL; 
}

void imprimirTListaExposiciones(TListaExposiciones listaExposiciones){
    if(listaExposiciones -> inicio != NULL){
        nodo actual = listaExposiciones -> inicio;
        while (actual != NULL){
            imprimirTExposicion(actual -> expo);
            actual = actual -> sig;
        }
            
    }
}

void liberarTListaExposiciones(TListaExposiciones &listaExposiciones, bool liberarExposiciones){
    nodo actual = listaExposiciones -> inicio;
    while(actual != NULL){
        nodo sig = actual -> sig;
        if(liberarExposiciones)
            liberarTExposicion(actual -> expo);
        delete actual;
        actual = sig;
    }
    delete listaExposiciones;
    listaExposiciones = NULL;
}

TListaExposiciones obtenerExposicionesFinalizadas(TListaExposiciones &listaExposiciones, TFecha fecha) {
    TListaExposiciones finalizadas = crearTListaExposicionesVacia();
    nodo actual = listaExposiciones->inicio;
    nodo prev = NULL;
    nodo temp_prev = NULL;

    while (actual != NULL) {
        if (compararTFechas(fechaFinTExposicion(actual->expo), fecha) == -1) {
            // Remover el nodo actual de la lista original
            nodo temp = actual;
            if (prev == NULL) {
                listaExposiciones->inicio = actual->sig;
            } else {
                prev->sig = actual->sig;
            }
            actual = actual->sig;

            // Insertar el nodo en la lista de finalizadas al final
            if (finalizadas -> inicio == NULL){
                finalizadas -> inicio = temp;
            } else {
                temp_prev -> sig = temp;
            }
            temp_prev = temp;
            temp -> sig = NULL;
        } else {
            prev = actual;
            actual = actual->sig;
        }
    }

    return finalizadas;
}

TListaExposiciones obtenerExposicionesActivas(TListaExposiciones &listaExposiciones, TFecha fecha) {
    TListaExposiciones activas = crearTListaExposicionesVacia();
    nodo actual = listaExposiciones->inicio;
    nodo prev = NULL;
    nodo temp_prev = NULL;

    while (actual != NULL) {
        if (compararTFechas(fechaInicioTExposicion(actual->expo), fecha) < 1 && compararTFechas(fecha, fechaFinTExposicion(actual->expo)) == -1) {
            // Remover el nodo actual de la lista original
            nodo temp = actual;
            if (prev == NULL) {
                listaExposiciones->inicio = actual->sig;
            } else {
                prev->sig = actual->sig;
            }
            actual = actual->sig;

            // Insertar el nodo en la lista de activas al final
            if (activas -> inicio == NULL){
                activas -> inicio = temp;
            } else {
                temp_prev -> sig = temp;
            }
            temp_prev = temp;
            temp -> sig = NULL;
        } else {
            prev = actual;
            actual = actual->sig;
        }
    }

    return activas;
}

bool esCompatibleTListaExposiciones(TListaExposiciones listaExposiciones, TExposicion expo){
    nodo actual = listaExposiciones -> inicio;
    while(actual != NULL && sonExposicionesCompatibles(actual -> expo, expo)){
        actual = actual -> sig;
    } 
    return actual == NULL; 
}

void insFinal(TExposicion expo, TListaExposiciones &listaExpo, nodo &ult){
    nodo nuevo = new nodo_listaexposiciones;
    nuevo -> expo = expo;
    nuevo -> sig = NULL;

    if (ult == NULL)
        listaExpo -> inicio = nuevo;
    else 
        ult -> sig = nuevo;
    
    ult = nuevo;
    listaExpo->cantElem++;
}

TListaExposiciones unirListaExposiciones(TListaExposiciones listaExpo1, TListaExposiciones listaExpo2) {
    TListaExposiciones unidas = crearTListaExposicionesVacia();
    nodo actual1 = listaExpo1->inicio;
    nodo actual2 = listaExpo2->inicio;
    nodo ult = NULL;

    while (actual1!=NULL && actual2!=NULL){
        if (compararTFechas(fechaInicioTExposicion(actual1->expo), fechaInicioTExposicion(actual2->expo)) < 1){
            insFinal(actual1->expo,unidas,ult);
            actual1 = actual1->sig;
        } else {
            insFinal (actual2->expo,unidas,ult);
            actual2 = actual2->sig;
        }
    } // O(n+m) siendo n y m los largos de las listas.
    while (actual1!=NULL) { 
        insFinal(actual1->expo,unidas,ult); actual1 = actual1->sig; 
    }
    while (actual2!=NULL) { 
        insFinal(actual2->expo,unidas,ult); actual2 = actual2->sig; 
    }
    
    return unidas;
}


// Agregados tarea 4


int cantidadExposicionesTListaExposiciones(TListaExposiciones listaExpo){
    return listaExpo->cantElem;
}

TExposicion obtenerNesimaExposicionTListaExposiciones(TListaExposiciones listaExpo, int n){
    int i = 1;
    nodo actual = listaExpo->inicio;
    while(actual != NULL){
        if(i == n) break;
        actual = actual->sig;
        i++;
    }
    return actual->expo;
}
