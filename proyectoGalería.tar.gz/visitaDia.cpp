#include "../include/visitaDia.h"

struct rep_visitadia{
  TFecha fecha;
  int maxGrupos;
  bool invertir;
  TGrupoABB *heap;
  int *idToIndex;
  int cantidadGrupos;
};

TVisitaDia crearTVisitaDia(TFecha fecha, int N){
  TVisitaDia nuevaVisitaDia = new rep_visitadia;
  nuevaVisitaDia -> fecha = fecha; 
  nuevaVisitaDia -> cantidadGrupos = 0;
  nuevaVisitaDia->heap = new TGrupoABB[N + 1]; 
  nuevaVisitaDia->idToIndex = new int[N + 1];
  nuevaVisitaDia->maxGrupos = N;
  nuevaVisitaDia->invertir = false;
  for(int i = 0; i <= N; i++){
    nuevaVisitaDia->idToIndex[i] = -1;
  }
  return nuevaVisitaDia; 
}

void swap(int pos, int pos2, TVisitaDia &visitaDia){
  TGrupoABB swap = visitaDia->heap[pos];
  visitaDia->heap[pos] = visitaDia->heap[pos2];
  visitaDia->heap[pos2] = swap;
  visitaDia->idToIndex[idGrupo(visitaDia->heap[pos])] = pos;
  visitaDia->idToIndex[idGrupo(visitaDia->heap[pos2])] = pos2;
}

bool tieneMasPrioridad(TVisitaDia visita, int pos1, int pos2){
  if(visita->invertir)
    return edadPromedioTGrupoABB(visita->heap[pos1]) > edadPromedioTGrupoABB(visita->heap[pos2]);
  else return edadPromedioTGrupoABB(visita->heap[pos1]) < edadPromedioTGrupoABB(visita->heap[pos2]);
}

void filtradoAscendente(int indice, TVisitaDia &visitaDia){
   while (indice > 1) {
    int indicePadre = indice / 2;

    if (tieneMasPrioridad(visitaDia, indice, indicePadre)) {
      swap(indice, indicePadre, visitaDia);
      indice = indicePadre;
    } 
    else break;
  }
}

void encolarGrupoTVisitaDia(TVisitaDia &visita, TGrupoABB grupo){
  if(visita->cantidadGrupos < visita->maxGrupos){
    int idx = visita->cantidadGrupos + 1;
    visita->heap[idx] = grupo; //agrego al final
    visita->idToIndex[idGrupo(grupo)] = idx;
    visita->cantidadGrupos++;
    filtradoAscendente(idx,visita);
  }
}


int cantidadGruposTVisitaDia(TVisitaDia visitaDia){
  return visitaDia->cantidadGrupos;
}

void imprimirTVisitaDia(TVisitaDia visitaDia){
  printf("Visita para dia: ");
  imprimirTFecha(visitaDia->fecha);
  printf("\n");

  int nivel = 1;
  int cantidadGrupos =visitaDia->cantidadGrupos;
  int gruposEnNivel = 1;
  int i = 1;

  while(i <= cantidadGrupos){
    printf("\nNivel %d\n", nivel);

    int gruposImpresos = 0;

    while(gruposImpresos < gruposEnNivel && i <= cantidadGrupos){
      TGrupoABB grupo = visitaDia->heap[i];
      printf("%d) Grupo %d con edad promedio %.2f\n", i, idGrupo(grupo), edadPromedioTGrupoABB(grupo));
      imprimirTGrupoABB(grupo);
      i++;
      gruposImpresos++;
    }

    nivel++;
    gruposEnNivel *= 2;
  }

}

void filtradoDescendente(TVisitaDia visita, int indice) {
  int tamano = visita->cantidadGrupos;
  while (indice * 2 <= tamano) {
      int indiceHijo = indice * 2;
      
      if (indiceHijo + 1 <= tamano && tieneMasPrioridad(visita, indiceHijo + 1, indiceHijo)) {       
              indiceHijo++;
      }

      if (tieneMasPrioridad(visita, indiceHijo, indice)) {
          swap(indice, indiceHijo, visita);
          indice = indiceHijo;

      } else break;
    }
}

TGrupoABB desencolarGrupoTVisitaDia(TVisitaDia &visita) {

    TGrupoABB grupoPrioritario = visita->heap[1];
    visita->heap[1] = visita->heap[visita->cantidadGrupos--];

    if (visita->cantidadGrupos > 0) {
        visita->idToIndex[idGrupo(visita->heap[1])] = 1;
        filtradoDescendente(visita, 1);
    }

    visita->idToIndex[idGrupo(grupoPrioritario)] = -1;
    return grupoPrioritario;
}

void liberarTVisitaDia(TVisitaDia &visitaDia){

    liberarTFecha(visitaDia -> fecha);
    for(int i = 1; i <= visitaDia->cantidadGrupos; i++){
      liberarTGrupoABB(visitaDia->heap[i]);
    }

    delete[] visitaDia->heap;
    delete[] visitaDia->idToIndex;
    delete visitaDia;
    visitaDia = NULL;
}

void invertirPrioridadTVisitaDia(TVisitaDia &visita) {
  visita->invertir = !visita->invertir;

  for(int i = (visita->cantidadGrupos/2); i > 0; i--)
    filtradoDescendente(visita, i);
}

bool estaEnTVisitaDia(TVisitaDia visita, int id) {
  return id >0 && id <= visita->cantidadGrupos && visita->idToIndex[id] != -1;
} 

float prioridadTVisitaDia(TVisitaDia visita, int id){
  return edadPromedioTGrupoABB(visita->heap[visita->idToIndex[id]]);
}

TGrupoABB masPrioritarioTVisitaDia(TVisitaDia visita){
	return visita->heap[1];
}


int maxGruposTVisitaDia(TVisitaDia visita){
  return visita->maxGrupos;
}

TFecha fechaTVisitaDia(TVisitaDia visitaDia){
  return visitaDia->fecha;
}


